import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Plane } from 'lucide-react';
import './auth.css';

const VIDEO_SRC = '/media/2026-08-24_Voyana-Journey_v1.mp4';

interface AuthLayoutProps {
  route: string;
  children: ReactNode;
}

function AuthLayout({ route, children }: AuthLayoutProps) {
  // A transient media abort should not permanently kill the scene: remount
  // the video up to twice before settling on the static fallback.
  const [videoState, setVideoState] = useState({ attempt: 0, failed: false });
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleVideoError = () => {
    setVideoState((prev) =>
      prev.attempt < 2 ? { attempt: prev.attempt + 1, failed: false } : { ...prev, failed: true },
    );
  };

  // Keep the scene alive: retry playback after mount and whenever the tab
  // becomes visible again (browsers pause background video).
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const tryPlay = () => {
      if (!document.hidden) video.play().catch(() => { /* first frame remains visible */ });
    };
    tryPlay();
    document.addEventListener('visibilitychange', tryPlay);
    return () => document.removeEventListener('visibilitychange', tryPlay);
  }, [videoState]);

  return (
    <div className="auth-page">
      <aside className="auth-visual" aria-hidden="true">
        <div className="auth-visual-fallback" />
        {!videoState.failed && (
          <video
            key={videoState.attempt}
            ref={videoRef}
            className="auth-video"
            src={VIDEO_SRC}
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            tabIndex={-1}
            disablePictureInPicture
            onError={handleVideoError}
          />
        )}
        <div className="auth-visual-overlay" />
        <a className="auth-brand" href="#/" tabIndex={-1}>
          <span className="brand-mark"><Plane size={17} strokeWidth={2.2} /></span>
          <span className="auth-brand-copy">
            <span className="auth-brand-name">VOYANA</span>
            <span className="auth-brand-tag">Let&apos;s explore the world</span>
          </span>
        </a>
        <div className="auth-visual-caption">
          <span className="auth-caption-line" />
          <p>Your next journey starts here.</p>
        </div>
      </aside>

      <main className="auth-panel">
        <div className="auth-card" key={route}>
          {children}
        </div>
        <p className="auth-safety">Your data is safe with us. We never share your information.</p>
      </main>
    </div>
  );
}

export default AuthLayout;
