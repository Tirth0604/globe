import { useEffect, useState, type FormEvent } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  Plane,
} from 'lucide-react';
import {
  EMAIL_PATTERN,
  forgetEmail,
  recallEmail,
  rememberEmail,
  signIn,
} from '@/services/authService';
import SocialAuth from './SocialAuth';

type Status = 'idle' | 'loading' | 'error' | 'success';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(false);
  const [status, setStatus] = useState<Status>('idle');
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});

  useEffect(() => {
    const saved = recallEmail();
    if (saved) {
      setEmail(saved);
      setRemember(true);
    }
  }, []);

  const validate = () => {
    const errors: { email?: string; password?: string } = {};
    if (!email.trim()) errors.email = 'Email is required.';
    else if (!EMAIL_PATTERN.test(email.trim())) errors.email = 'Please enter a valid email address.';
    if (!password) errors.password = 'Password is required.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (status === 'loading' || status === 'success') return;
    setFormError(null);
    if (!validate()) return;

    setStatus('loading');
    const result = await signIn(email.trim(), password);
    if (!result.ok) {
      setStatus('error');
      setFormError(result.message);
      return;
    }

    if (remember) rememberEmail(email.trim());
    else forgetEmail();
    setStatus('success');
    window.setTimeout(() => {
      window.location.hash = '/';
    }, 1400);
  };

  const busy = status === 'loading';

  return (
    <div className="auth-stagger">
      <div className="auth-icon-badge" aria-hidden="true">
        <Plane size={22} strokeWidth={2} />
      </div>
      <h1 className="auth-heading">Welcome back</h1>
      <p className="auth-subheading">Continue your journey with Voyana.</p>

      {formError && (
        <div className="auth-alert auth-alert-error" role="alert">
          <AlertCircle size={16} />
          <span>{formError}</span>
        </div>
      )}
      {status === 'success' && (
        <div className="auth-alert auth-alert-success" role="status">
          <CheckCircle2 size={16} />
          <span>Welcome back! Preparing your journey…</span>
        </div>
      )}

      <form className="auth-form" onSubmit={handleSubmit} noValidate>
        <div className="auth-field">
          <label htmlFor="login-email">Email</label>
          <div className={`auth-input-wrap ${fieldErrors.email ? 'has-error' : ''}`}>
            <Mail size={17} aria-hidden="true" />
            <input
              id="login-email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.email)}
              aria-describedby={fieldErrors.email ? 'login-email-error' : undefined}
              onChange={(event) => {
                setEmail(event.target.value);
                if (fieldErrors.email) setFieldErrors((prev) => ({ ...prev, email: undefined }));
              }}
            />
          </div>
          {fieldErrors.email && <p className="auth-field-error" id="login-email-error">{fieldErrors.email}</p>}
        </div>

        <div className="auth-field">
          <label htmlFor="login-password">Password</label>
          <div className={`auth-input-wrap ${fieldErrors.password ? 'has-error' : ''}`}>
            <Lock size={17} aria-hidden="true" />
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              placeholder="Enter your password"
              value={password}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.password)}
              aria-describedby={fieldErrors.password ? 'login-password-error' : undefined}
              onChange={(event) => {
                setPassword(event.target.value);
                if (fieldErrors.password) setFieldErrors((prev) => ({ ...prev, password: undefined }));
              }}
            />
            <button
              type="button"
              className="auth-eye-button"
              onClick={() => setShowPassword((value) => !value)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              aria-pressed={showPassword}
            >
              {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          {fieldErrors.password && <p className="auth-field-error" id="login-password-error">{fieldErrors.password}</p>}
        </div>

        <div className="auth-form-row">
          <label className="auth-check">
            <input
              type="checkbox"
              checked={remember}
              disabled={busy}
              onChange={(event) => setRemember(event.target.checked)}
            />
            <span className="auth-check-box" aria-hidden="true" />
            <span>Remember me</span>
          </label>
          <a className="auth-inline-link" href="#/forgot-password">Forgot password?</a>
        </div>

        <button type="submit" className={`auth-submit ${status === 'success' ? 'is-success' : ''}`} disabled={busy || status === 'success'}>
          {status === 'loading' && (
            <>
              <Loader2 size={18} className="auth-spinner" aria-hidden="true" /> Signing in…
            </>
          )}
          {status === 'success' && (
            <>
              <CheckCircle2 size={18} aria-hidden="true" /> Welcome back!
            </>
          )}
          {(status === 'idle' || status === 'error') && (
            <>
              Sign In <ArrowRight size={18} aria-hidden="true" />
            </>
          )}
        </button>
      </form>

      <SocialAuth />

      <p className="auth-switch">
        Don&apos;t have an account? <a href="#/signup">Create account</a>
      </p>
    </div>
  );
}

export default LoginPage;
