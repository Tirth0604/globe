import type { GlobeLocation, GlobeLocationType } from '@/components/Globe/globe.types';

interface LocationSeed {
  name: string;
  city?: string;
  state?: string;
  country?: string;
  latitude: number;
  longitude: number;
  type: GlobeLocationType;
  aliases?: string[];
}

const locationSeeds: LocationSeed[] = [
  { name: 'Paris', city: 'Paris', country: 'France', latitude: 48.8566, longitude: 2.3522, type: 'city', aliases: ['paris, france', 'paris france'] },
  { name: 'Tokyo', city: 'Tokyo', country: 'Japan', latitude: 35.6762, longitude: 139.6503, type: 'city', aliases: ['tokyo, japan', 'tokyo japan'] },
  { name: 'Dubai', city: 'Dubai', country: 'United Arab Emirates', latitude: 25.2048, longitude: 55.2708, type: 'city', aliases: ['dubai, uae', 'dubai uae'] },
  { name: 'New York', city: 'New York', state: 'New York', country: 'United States', latitude: 40.7128, longitude: -74.006, type: 'city', aliases: ['new york, usa', 'nyc', 'new york city'] },
  { name: 'Ahmedabad', city: 'Ahmedabad', state: 'Gujarat', country: 'India', latitude: 23.0225, longitude: 72.5714, type: 'city', aliases: ['ahmedabad, india', 'ahmedabad gujarat'] },
  { name: 'Mumbai', city: 'Mumbai', state: 'Maharashtra', country: 'India', latitude: 19.076, longitude: 72.8777, type: 'city', aliases: ['mumbai, india', 'bombay'] },
  { name: 'London', city: 'London', country: 'United Kingdom', latitude: 51.5074, longitude: -0.1278, type: 'city', aliases: ['london, uk', 'london uk'] },
  { name: 'Sydney', city: 'Sydney', state: 'New South Wales', country: 'Australia', latitude: -33.8688, longitude: 151.2093, type: 'city', aliases: ['sydney, australia'] },
  { name: 'Singapore', city: 'Singapore', country: 'Singapore', latitude: 1.3521, longitude: 103.8198, type: 'city' },
  { name: 'Rome', city: 'Rome', country: 'Italy', latitude: 41.9028, longitude: 12.4964, type: 'city', aliases: ['rome, italy'] },
  { name: 'Bangkok', city: 'Bangkok', country: 'Thailand', latitude: 13.7563, longitude: 100.5018, type: 'city' },
  { name: 'Rio de Janeiro', city: 'Rio de Janeiro', state: 'Rio de Janeiro', country: 'Brazil', latitude: -22.9068, longitude: -43.1729, type: 'city', aliases: ['rio', 'rio, brazil'] },
  { name: 'France', country: 'France', latitude: 46.6034, longitude: 1.8883, type: 'country' },
  { name: 'Japan', country: 'Japan', latitude: 36.2048, longitude: 138.2529, type: 'country' },
  { name: 'India', country: 'India', latitude: 22.5937, longitude: 78.9629, type: 'country' },
  { name: 'United States', country: 'United States', latitude: 39.8283, longitude: -98.5795, type: 'country', aliases: ['usa', 'us', 'america'] },
  { name: 'Australia', country: 'Australia', latitude: -25.2744, longitude: 133.7751, type: 'country' },
  { name: 'Italy', country: 'Italy', latitude: 41.8719, longitude: 12.5674, type: 'country' },
  { name: 'Switzerland', country: 'Switzerland', latitude: 46.8182, longitude: 8.2275, type: 'country' },
  { name: 'Gujarat', state: 'Gujarat', country: 'India', latitude: 22.2587, longitude: 71.1924, type: 'state' },
];

export function searchLocations(query: string): GlobeLocation[] {
  const normalized = query.toLowerCase().trim();
  if (!normalized) return [];
  const matches = locationSeeds.filter((seed) => {
    const haystack = [seed.name, seed.city, seed.state, seed.country, ...(seed.aliases ?? [])].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(normalized);
  });
  return matches.slice(0, 6).map((seed) => ({ ...seed }));
}

export function resolveLocation(query: string): GlobeLocation | null {
  const normalized = query.toLowerCase().trim();
  if (!normalized) return null;
  const exact = locationSeeds.find((seed) => seed.name.toLowerCase() === normalized || seed.aliases?.some((alias) => alias.toLowerCase() === normalized));
  if (exact) return { ...exact };
  const partial = locationSeeds.find((seed) => {
    const haystack = [seed.name, seed.city, seed.state, seed.country, ...(seed.aliases ?? [])].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(normalized);
  });
  return partial ? { ...partial } : null;
}

export function suggestDestinations(query: string): GlobeLocation[] {
  return searchLocations(query).slice(0, 5);
}
