import { useState, type FormEvent } from 'react';
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Mail,
  User,
  UserPlus,
} from 'lucide-react';
import { EMAIL_PATTERN, MIN_PASSWORD_LENGTH, signUp } from '@/services/authService';
import SocialAuth from './SocialAuth';

type Status = 'idle' | 'loading' | 'error' | 'success';

interface FieldErrors {
  name?: string;
  email?: string;
  password?: string;
  confirm?: string;
  terms?: string;
}

function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [status, setStatus] = useState<Status>('idle');
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});

  const clearFieldError = (key: keyof FieldErrors) => {
    setFieldErrors((prev) => (prev[key] ? { ...prev, [key]: undefined } : prev));
  };

  const validate = () => {
    const errors: FieldErrors = {};
    if (!name.trim()) errors.name = 'Full name is required.';
    if (!email.trim()) errors.email = 'Email is required.';
    else if (!EMAIL_PATTERN.test(email.trim())) errors.email = 'Please enter a valid email address.';
    if (!password) errors.password = 'Password is required.';
    else if (password.length < MIN_PASSWORD_LENGTH) errors.password = `Use at least ${MIN_PASSWORD_LENGTH} characters.`;
    if (confirm !== password) errors.confirm = 'Passwords do not match.';
    if (!agreed) errors.terms = 'Please accept the Terms of Service to continue.';
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (status === 'loading' || status === 'success') return;
    setFormError(null);
    if (!validate()) return;

    setStatus('loading');
    const result = await signUp(name.trim(), email.trim(), password);
    if (!result.ok) {
      setStatus('error');
      setFormError(result.message);
      return;
    }
    setStatus('success');
    window.setTimeout(() => {
      window.location.hash = '/login';
    }, 1600);
  };

  const busy = status === 'loading';

  return (
    <div className="auth-stagger">
      <div className="auth-icon-badge" aria-hidden="true">
        <UserPlus size={22} strokeWidth={2} />
      </div>
      <h1 className="auth-heading">Create Account</h1>
      <p className="auth-subheading">Start your adventure today.</p>

      {formError && (
        <div className="auth-alert auth-alert-error" role="alert">
          <AlertCircle size={16} />
          <span>{formError}</span>
        </div>
      )}
      {status === 'success' && (
        <div className="auth-alert auth-alert-success" role="status">
          <CheckCircle2 size={16} />
          <span>Account created. Taking you to sign in…</span>
        </div>
      )}

      <form className="auth-form" onSubmit={handleSubmit} noValidate>
        <div className="auth-field">
          <label htmlFor="signup-name">Full Name</label>
          <div className={`auth-input-wrap ${fieldErrors.name ? 'has-error' : ''}`}>
            <User size={17} aria-hidden="true" />
            <input
              id="signup-name"
              type="text"
              autoComplete="name"
              placeholder="Your full name"
              value={name}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.name)}
              aria-describedby={fieldErrors.name ? 'signup-name-error' : undefined}
              onChange={(event) => { setName(event.target.value); clearFieldError('name'); }}
            />
          </div>
          {fieldErrors.name && <p className="auth-field-error" id="signup-name-error">{fieldErrors.name}</p>}
        </div>

        <div className="auth-field">
          <label htmlFor="signup-email">Email Address</label>
          <div className={`auth-input-wrap ${fieldErrors.email ? 'has-error' : ''}`}>
            <Mail size={17} aria-hidden="true" />
            <input
              id="signup-email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.email)}
              aria-describedby={fieldErrors.email ? 'signup-email-error' : undefined}
              onChange={(event) => { setEmail(event.target.value); clearFieldError('email'); }}
            />
          </div>
          {fieldErrors.email && <p className="auth-field-error" id="signup-email-error">{fieldErrors.email}</p>}
        </div>

        <div className="auth-field">
          <label htmlFor="signup-password">Password</label>
          <div className={`auth-input-wrap ${fieldErrors.password ? 'has-error' : ''}`}>
            <Lock size={17} aria-hidden="true" />
            <input
              id="signup-password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="new-password"
              placeholder="Create a password"
              value={password}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.password)}
              aria-describedby={fieldErrors.password ? 'signup-password-error' : undefined}
              onChange={(event) => { setPassword(event.target.value); clearFieldError('password'); }}
            />
            <button
              type="button"
              className="auth-eye-button"
              onClick={() => setShowPassword((value) => !value)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
              aria-pressed={showPassword}
            >
              {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          {fieldErrors.password && <p className="auth-field-error" id="signup-password-error">{fieldErrors.password}</p>}
        </div>

        <div className="auth-field">
          <label htmlFor="signup-confirm">Confirm Password</label>
          <div className={`auth-input-wrap ${fieldErrors.confirm ? 'has-error' : ''}`}>
            <Lock size={17} aria-hidden="true" />
            <input
              id="signup-confirm"
              type={showConfirm ? 'text' : 'password'}
              autoComplete="new-password"
              placeholder="Repeat your password"
              value={confirm}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.confirm)}
              aria-describedby={fieldErrors.confirm ? 'signup-confirm-error' : undefined}
              onChange={(event) => { setConfirm(event.target.value); clearFieldError('confirm'); }}
            />
            <button
              type="button"
              className="auth-eye-button"
              onClick={() => setShowConfirm((value) => !value)}
              aria-label={showConfirm ? 'Hide password' : 'Show password'}
              aria-pressed={showConfirm}
            >
              {showConfirm ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          {fieldErrors.confirm && <p className="auth-field-error" id="signup-confirm-error">{fieldErrors.confirm}</p>}
        </div>

        <div className="auth-field">
          <label className="auth-check">
            <input
              type="checkbox"
              checked={agreed}
              disabled={busy}
              aria-invalid={Boolean(fieldErrors.terms)}
              aria-describedby={fieldErrors.terms ? 'signup-terms-error' : undefined}
              onChange={(event) => { setAgreed(event.target.checked); clearFieldError('terms'); }}
            />
            <span className="auth-check-box" aria-hidden="true" />
            <span>
              I agree to the <a className="auth-inline-link" href="#/terms">Terms of Service</a> and{' '}
              <a className="auth-inline-link" href="#/privacy">Privacy Policy</a>
            </span>
          </label>
          {fieldErrors.terms && <p className="auth-field-error" id="signup-terms-error">{fieldErrors.terms}</p>}
        </div>

        <button type="submit" className={`auth-submit ${status === 'success' ? 'is-success' : ''}`} disabled={busy || status === 'success'}>
          {status === 'loading' && (
            <>
              <Loader2 size={18} className="auth-spinner" aria-hidden="true" /> Creating account…
            </>
          )}
          {status === 'success' && (
            <>
              <CheckCircle2 size={18} aria-hidden="true" /> Welcome aboard!
            </>
          )}
          {(status === 'idle' || status === 'error') && (
            <>
              Sign Up <ArrowRight size={18} aria-hidden="true" />
            </>
          )}
        </button>
      </form>

      <SocialAuth />

      <p className="auth-switch">
        Already have an account? <a href="#/login">Sign In</a>
      </p>
    </div>
  );
}

export default SignupPage;
